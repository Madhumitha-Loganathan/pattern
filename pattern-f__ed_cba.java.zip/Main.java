import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        int rows = scanner.nextInt();
        int n=0;
        for(int i=rows;i>0;i--)
        {
            n=n+i;
        }
        int alphabet = 65;
        //System.out.print(n);

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j <= i; j++)
            {
                System.out.print((char) (alphabet + n-1) + " ");
                n--;
            }
            System.out.println();
        }
    }
}