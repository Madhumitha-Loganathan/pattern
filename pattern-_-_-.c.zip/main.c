/*
*
**
***
****
*/
#include<stdio.h>
int main()
{
    int number,i,j;
    printf("Enter the number of lines to be printed ");
    scanf("%d",&number);
    for(i=0;i<number;i++)
    {
        for(j=0;j<=i;j++)
        {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}