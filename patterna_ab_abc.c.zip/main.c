/*Output
A 
AB 
ABC
ABCD
*/
#include<stdio.h>
int main()
{
    int number,i,j,n;
    char ch;
    printf("Enter the number of lines to be printed ");
    scanf("%d",&number);
    for(i=0;i<number;i++)
    {
        ch='A';
        for(j=0;j<=i;j++)
        {
            printf("%c",ch);
            ch++;
        }
        printf("\n");
    }
    return 0;
}
