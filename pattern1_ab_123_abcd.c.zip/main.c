/*
1 
AB 
123 
ABCD
*/
#include <stdio.h>

int main()
{
    int num,i,j,n;
    char ch;
    printf("Enter the number ");
    scanf("%d",&num);
    for(i=1;i<=num;i++)
    {
        if(i%2==0)
        {
            ch='A';
            for(j=1;j<=i;j++)
            {
                printf("%c",ch);
                ch++;
            }
            
        }
        else
        {
            n=1;
            for(j=1;j<=i;j++)
            {
                printf("%d",n);
                n++;
            }
        }
        printf("\n");
    }

    return 0;
}

